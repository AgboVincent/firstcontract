import 'package:flutter/material.dart';
import 'package:gen128/homepage/profile.dart';
import 'package:gen128/report/armed_robbery.dart';
import 'package:gen128/report/civil_unrest.dart';
import 'package:gen128/report/fire_outbreak.dart';
import 'package:gen128/report/rape.dart';
import 'package:gen128/report/kidnap.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

class CustomDrawer extends StatefulWidget {
  @override
  CustomDrawerState createState() => CustomDrawerState();
}

enum Report { armedRobbery, rape, kidnap, civilUnrest, fireOutbreak }

class CustomDrawerState extends State<CustomDrawer> {
  Future<void> OpenDialog() async {
    switch (await showDialog(
        context: context,
        builder: (BuildContext context) {
          return SimpleDialog(
            title: const Text("What kind of Report"),
            children: <Widget>[
              SimpleDialogOption(
                onPressed: () {
                  Navigator.pop(context, Report.armedRobbery);
                },
                child: const Text("Armed Robbery"),
              ),
              SimpleDialogOption(
                onPressed: () {
                  Navigator.pop(context, Report.rape);
                },
                child: const Text("Rape"),
              ),
              SimpleDialogOption(
                onPressed: () {
                  Navigator.pop(context, Report.kidnap);
                },
                child: const Text("Kidnap"),
              ),
              SimpleDialogOption(
                onPressed: () {
                  Navigator.pop(context, Report.civilUnrest);
                },
                child: const Text("Civil Unrest"),
              ),
              SimpleDialogOption(
                onPressed: () {
                  Navigator.pop(context, Report.fireOutbreak);
                },
                child: const Text("Fire Outbreak"),
              )
            ],
          );
        })) {
      case Report.armedRobbery:
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => ArmedRobbery()));
        break;

      case Report.rape:
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => Rape()));
        break;

      case Report.kidnap:
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => Kidnap()));
        break;

      case Report.civilUnrest:
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => CivilUnrest()));
        break;

      case Report.fireOutbreak:
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => FireOutbreak()));
        break;
    }
  }

  File image;

  //Open gallery
  Future<void> chooseImage() async {
    var choosedimage = await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      image = choosedimage;
    });
  }

  Future uploadImage() async {
    final uri = Uri.parse('http://192.168.43.42/form/profile_pic.php');
    var request = http.MultipartRequest('POST', uri);
    var pic = await http.MultipartFile.fromPath("image", image.path);
    request.files.add(pic);
    var response = await request.send();
    if (response.statusCode == 200) {
      print('profile pic uploaded successfully');
    } else {
      print('profile pic not uploaded');
    }
  }

  Widget imageUpload() {
    if (image == null) {
      Icon(Icons.person, color: Colors.white);
    } else {
      Image.file(image);
      uploadImage();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Center(
            child: UserAccountsDrawerHeader(
                accountName: Text('Name'),
                accountEmail: Text('*********@gmail.com'),
                currentAccountPicture: GestureDetector(
                  onTap: () {
                    chooseImage();
                  },
                  child: Stack(
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.grey,
                        child: image == null
                        ? Icon(Icons.person,color: Colors.white,)
                        : Image.file(image)
                      ),
                    ],
                  )
                ),
                decoration: BoxDecoration(color: Colors.green)),
          ),
          ListTile(
              leading: Icon(Icons.person, color: Colors.redAccent),
              title: Text('My Profile'),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (BuildContext context) {
                //  return Profile();
                }));
              }),
          ListTile(
            leading: Icon(Icons.add_circle, color: Colors.redAccent),
            title: Text('Add Report'),
            onTap: () {
              OpenDialog();
            },
          ),
          ListTile(
            leading: Icon(Icons.add_circle, color: Colors.redAccent),
            title: Text('Add Report'),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.add_circle, color: Colors.redAccent),
            title: Text('Add Report'),
            onTap: () {},
          ),
          Divider(color: Colors.red, indent: 20.0),
          ListTile(
            //     leading: Icon(Icons.settings, color: Colors.blue),
            title: Text('Sign Up'),
            onTap: () {},
          ),
          ListTile(
            //    leading: Icon(Icons.help, color: Colors.green),
            title: Text('Login'),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
